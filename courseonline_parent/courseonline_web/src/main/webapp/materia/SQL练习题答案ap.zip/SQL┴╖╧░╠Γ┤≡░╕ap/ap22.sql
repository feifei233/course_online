SELECT job_id
FROM   employees
WHERE  hire_date 
BETWEEN '01-JAN-1990' AND '30-JUN-1990'
INTERSECT
SELECT job_id
FROM   employees
WHERE  hire_date BETWEEN '01-JAN-1991'AND '30-JUN-1991';
