SELECT e.employee_id, e.last_name,
       e.department_id,   AVG(s.salary)
FROM   employees e, employees s
WHERE   e.department_id = s.department_id
GROUP BY e.employee_id, e.last_name, e.department_id
/
