COLUMN name FORMAT A25
SELECT  employee_id, manager_id, LEVEL,
LPAD(last_name, LENGTH(last_name)+(LEVEL*2)-2,'_')  LAST_NAME        
FROM    employees
CONNECT BY employee_id = PRIOR manager_id;
COLUMN name CLEAR

