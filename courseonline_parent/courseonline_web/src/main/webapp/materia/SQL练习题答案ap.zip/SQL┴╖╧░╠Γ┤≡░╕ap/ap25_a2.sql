SELECT TZ_OFFSET ('Chile/EasterIsland') from dual;
