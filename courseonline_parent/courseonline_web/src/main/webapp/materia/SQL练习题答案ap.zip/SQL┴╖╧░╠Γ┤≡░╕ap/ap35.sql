SELECT employee_id, manager_id, level, last_name
FROM   employees
WHERE LEVEL = 3
CONNECT BY manager_id = PRIOR employee_id
START WITH employee_id= 102;
