SELECT employee_id, last_name, hire_date, salary
FROM   employees
WHERE  manager_id = (SELECT employee_id
           FROM   employees
	           WHERE last_name = 'De Haan');
