SELECT d.department_id, d.department_name,
       d.location_id,   COUNT(e.employee_id)
FROM   employees e, departments d
WHERE   e.department_id(+) = d.department_id
GROUP BY d.department_id, d.department_name, d.location_id
/
