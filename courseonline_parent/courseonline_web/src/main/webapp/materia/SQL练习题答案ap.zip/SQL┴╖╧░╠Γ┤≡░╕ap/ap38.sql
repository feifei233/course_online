SELECT * FROM special_sal;
SELECT * FROM sal_history;
SELECT * FROM mgr_history;

