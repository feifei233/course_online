SET HEADING OFF ECHO OFF FEEDBACK OFF 
SET PAGESIZE 0

   

     SELECT   'DROP ' || object_type || ' ' || object_name || ';'
     FROM     user_objects
     ORDER BY object_type
     /



     SET HEADING ON ECHO ON FEEDBACK ON 
     SET PAGESIZE 24     

